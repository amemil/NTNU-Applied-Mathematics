#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar  8 12:29:03 2019

@author: christianlehre
"""

import numpy as np
import numpy.linalg as la
import algorithms as alg
import datetime
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.cm as cm

def generate_w(z,A,c,N,d,model):
    x_sample = z.T[0]
    y_sample = z.T[1]

    eps = 1e-10
    labels = -np.ones(len(x_sample))
    if model == 1:
        for i in range(len(x_sample)):
                x = (x_sample[i],y_sample[i])
                Ax = A@(x-c)
                if (x-c).T@Ax -1.0 < eps:
                    labels[i] = 1
    elif model == 2:
        b = c
        for i in range(len(x_sample)):
            z = np.array([x_sample[i],y_sample[i]])
            Az = A@z
            if z.T@Az- z.T@b -1.0 < eps:
                labels[i] = 1
    else:
        raise ValueError('Invalid model choice')
    return labels

def generate_zw(z,A,c,N,d,model):
    """
    return array of labels and perturbed data-points
    """
    w = generate_w(z,A,c,N,d,model)

    #perturb datapoints - keep labels constant
    z_pert = z + np.random.uniform(low = -0.5,high = 0.5,size = (N,d))    

    return (z_pert,w)



def make_Ac(x,d =2):
    A = np.zeros((d,d))
    c = np.zeros(d)
    
    A[0][0] = x[0]
    A[0][1],A[1][0] = x[1],x[1]
    A[1][1] = x[2]
    
    c[0] = x[3]
    c[1] = x[4]
    return A, c

def not_posdef(A):
    """
    checks whether any 2x2 matrix A is not positive definite
    """
    return ((A[0][0] <= 0 and A[1][1] <= 0 ) or la.det(A) <= 0)

def generate_random(N,d,scale):
    x = np.random.randn(5)
    z = np.random.uniform(low = -scale,high=scale,size=(N,d)) # randn
    return x,z 

def hi(x, zi,model):
    A, c = make_Ac(x,2)
    if model == 1:
        return (zi-c).dot(A.dot(zi-c)) - 1
    elif model == 2:
        b = c
        return zi.T@A@zi - zi.T@b - 1
    else:
        raise ValueError('Invalid model')

# Calculate residual r for single point z
def r(x, zi, wi,model):
    return np.maximum(wi * hi(x, zi,model), 0)

def R(x, Z, W,model):
    m, n = Z.shape
    R = np.zeros(m)
    for i in range(R.size):
        R[i] = r(x, Z[i], W[i],model)
    return R

def f(x, Z, W,model):
    """
    returns value of the objective function
    """
    m, n = Z.shape
    return np.sum(R(x, Z, W,model)**2)

def dhi(x, zi,model):
    dh = np.zeros(x.size)
    A, c = make_Ac(x,2)
    if model == 1:
        dh[0] = zi[0]**2 - 2*zi[0]*c[0] + c[0]**2
        dh[1] = 2*(zi[0]*zi[1] - zi[0]*c[1] - zi[1]*c[0] + c[0]*c[1])
        dh[2] = zi[1]**2 - 2*zi[1]*c[1] + c[1]**2
        dh[3] = -2*zi[0]*A[0][0] + 2*c[0]*A[0][0] - 2*zi[1]*A[0][1] + 2*c[1]*A[0][1]
        dh[4] = -2*zi[0]*A[0][1] + 2*c[0]*A[0][1] - 2*zi[1]*A[1][1] + 2*c[1]*A[1][1]

    elif model == 2:
        dh[0] = zi[0]**2
        dh[1] = 2*zi[0]*zi[1]
        dh[2] = zi[1]**2
        dh[3] = -zi[0]
        dh[4] = -zi[1]

    else:
        raise ValueError('Invalid model')
    return dh


def dri(x, zi, wi,model):
    """
    returns gradient of the residual for a single point z = (x,y)
    """    
    ri = r(x, zi, wi,model)
    return (ri > 0) * dhi(x, zi,model) * wi

def jacobi(x, Z, W,model):
    """
    returns the jacobian of the residual-vector
    """
    m, n = Z.shape
    J = np.zeros((m, x.size))
    for i in range(m):
        J[i] = dri(x, Z[i], W[i],model)
    return J

def df(x, Z, W,model):
    """
    returns gradient of objective function
    """
    return 2 * (jacobi(x, Z, W,model).T).dot(R(x, Z, W,model))


############# Objective function #########################################

def faugL(x,l,mu, Z,W, model, constr_p):
    p1 = f(x,Z,W, model)
    p2 = -l[0]*c0(x, constr_p) - l[1]*c1(x, constr_p) - l[2]*c2(x, constr_p)
    p3 = mu*0.5*(c0(x,constr_p)**2 + c1(x,constr_p)**2 + c2(x,constr_p)**2 )
    #print('c0=', c0(x, constr_p), 'c1=', c1(x, constr_p), 'c2=', c2(x, constr_p))
    return  p2 + p3  + p1

def dfaugL(x, l,mu,Z, W,model, constr_p):
    """
    returns gradient of objective function
    """
    dfdx = 2 * (jacobi(x, Z, W,model).T).dot(R(x, Z, W,model))
    dc0dx = l[0]*dc0(x, constr_p)
    dc1dx = l[1]*dc1(x, constr_p)
    dc2dx = l[2]*dc2(x, constr_p)
    
    ret = dfdx - dc0dx -dc1dx - dc2dx \
    +mu*(c1(x, constr_p)*dc1dx+c2(x, constr_p)*dc2dx+c0(x, constr_p)*dc0dx)
    return ret

############## Constraints ##############################################@
    
def c0(x, constr_p):
    A, c = make_Ac(x)
    ret = (A[0,0]-constr_p[0])*(A[0,0]-constr_p[1])
    if ret<0:
        return 0.0
    return ret

def c1(x, constr_p):
    A, c = make_Ac(x)
    ret= (A[1,1]-constr_p[0])*(A[1,1]-constr_p[1])
    if ret<0:
        return 0.0
    return ret

def c2(x, constr_p):
    A, c = make_Ac(x)
    ret= -np.sqrt(A[0,0]*A[1,1])+np.sqrt(constr_p[0]**2+A[0,1]**2)+constr_p[2]
    if ret<0:
        return 0.0
    return ret

def dc0(x, constr_p):
    if c0(x,constr_p)<=0.0:
        return 0.0
    else:
        A, c = make_Ac(x)
        dc1dA00 = 2*A[0,0]-constr_p[0]-constr_p[1]
    return np.array([dc1dA00, 0, 0, 0, 0])
    
def dc1(x, constr_p):
    if c1(x, constr_p)<=0.0:
        return 0.0
    else:
        A, c = make_Ac(x)
        dc1dA11 = 2*A[1,1]-constr_p[0]-constr_p[1]
        return np.array([0, 0, dc1dA11, 0, 0])
def dc2(x, constr_p):
    if c2(x, constr_p)<=0.0:
        return 0.0
    else:
        A, c = make_Ac(x)
        dc2dA00=-0.5/np.sqrt(A[0,0]*A[1,1])*A[1,1]
        dc2dA11=-0.5/np.sqrt(A[0,0]*A[1,1])*A[0,0]
        dc2dA12=(constr_p[0]**2+A[0,1]**2)*A[0,1]
    return np.array([dc2dA00, dc2dA12, dc2dA11, 0, 0])

def updateL(l, x, mu, constr_p):
    l[0] = l[0]- mu*c0(x,constr_p)
    l[1] = l[1]- mu*c1(x,constr_p)
    l[2] = l[2] -mu*c2(x,constr_p)
    return l




############ Augmented lagrangian for constrained setting ###################

def set_funcs_augL(z,w,model, constr_p):
    """
    returns anonymous functions for the objective function and its gradient
    """
    return lambda x, l, mu: faugL(x,l,mu, z,w, model, constr_p), \
           lambda x, l, mu: dfaugL(x, l,mu,z, w,model, constr_p),\
           lambda l, x, mu: updateL(l, x, mu, constr_p ), \
  

########## plot ##################################################
def plot_level_curves(
    f, 
    xrange, 
    yrange, 
    mode, 
    title, 
    param,  
    xpoints=None, 
    ypoints=None, 
    A1 = None, 
    c1 = None,
    As = None, 
    cs = None, 
    delta = 0.05
    ):
    
    
    x_lower = xrange[0]
    x_upper = xrange[1]
    y_lower = yrange[0]
    y_upper = yrange[1]
    xx = np.arange(x_lower,x_upper,delta)
    yy = np.arange(y_lower,y_upper,delta)
    X, Y = np.meshgrid(xx,yy)
    Z = []
    now = datetime.datetime.now()
    for y_i in range(0, len(yy)):
        Z +=  [[]]
        for x_i in range(0,len(xx)):
            Z[y_i].append(f(xx[x_i], yy[y_i]))
    Z = np.array(Z)
    if mode == 'contour':                                    
        plt.imshow(Z, interpolation='bilinear',
                        origin='lower', cmap=cm.Blues, 
                        extent=(x_lower,x_upper,y_lower,y_upper))
        plt.contour(X,Y,Z, cmap =cm.Blues)
        
    if mode == '3D':
        fig = plt.figure()
        ax = Axes3D(fig)
        ax.plot_surface( X, Y, Z)
    try:
        if xpoints.all()!= None:
            plt.plot(xpoints,ypoints,'k-',linewidth=1)
    except: 
        pass
    
    #plt.show()
    plt.savefig('level_curves/{0}_{1}_{2}{3}{4}_{5}{6}{7}.png'.format(title, param, now.year, now.month, now.day, now.hour, now.minute, now.second))
    plt.title(title)
    
    try:
        if A1.all()!=None:
            tst.plot_surface(As,cs,z,w,scale,'k','gen',model)
            tst.plot_surface(A1,c1,z,w,scale,'g','augL',model)
            plt.show()
            plt.savefig('results/{0}_{1}_{2}{3}{4}_{5}{6}{7}.png'.format(title, param, now.year, now.month, now.day, now.hour, now.minute, now.second))
    except:
        pass

def surface(X,Y,A,c,model):
    """
    returns the hypersurface
    """
    if model == 1:
        return A[0][0]*(X-c[0])**2+2*A[0][1]*(X-c[0])*(Y-c[1])+A[1][1]*(Y-c[1])**2-1
    elif model == 2:
        b = c
        return A[0][0]*X**2 + 2*A[0][1]*X*Y + A[1][1]*Y**2 - (b[0]*X + b[1]*Y) -1
    else:
        raise ValueError('Invalid model choice')

def plot_surface(A,c,z,w,area,col,label,model, title):
    """
    Plots hypersurface. 
    If ellipse, also plot the ellipse seperating the data
    """
    delta = 0.01
    colors = ['r' if i == 1 else 'b' for i in w]
    x = np.arange(-area*1.2, 1.2*area+delta, delta)
    y = np.arange(-area*1.2, 1.2*area+delta, delta)
    X, Y = np.meshgrid(x, y)
    Z = surface(X, Y, A, c,model)
    CS = plt.contour(X, Y, Z, [0], linewidths=2, zorder=10, colors = col)
    plt.clabel(CS, fmt=label, fontsize=10)
    if not label == 'gen':
        plt.scatter(z.T[0],z.T[1],c = colors)
    plt.grid(False)
    plt.title(title)

if __name__ == "__main__":
    print('run main instead of utilities to see results')
    
    
    


    