#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  5 21:55:34 2019

@author: christianlehre
"""

import numpy as np
from matplotlib import pyplot as plt




##### Define and plot the hypersurface #####


############################################


if __name__ == "__main__":
    N = 100
    d = 2

    A = np.array([[2,-1],[-1,2]])
    c = np.array([0,0])


    z = np.random.uniform(low = -3,high = 3,size = (N,d))


