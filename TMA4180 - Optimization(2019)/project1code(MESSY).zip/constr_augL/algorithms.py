# -*- coding: utf-8 -*-
import numpy as np
import numpy.linalg as la

def gradient_descent_augL(f,grad, updateL,  x0,tol, mu_k, l_k):
    """
    Gradient descent algorithm
    """
    cc1,cc2,alpha0 = 0.25, 0.5, 1
    p_k = -grad(x0, l_k, mu_k)
    x_k = x0
    x_k_ = x0 + np.ones((5,1))*100
    Nmax = 100
    
    conv_p = [x0]
    
    
    
    it = 0
    while la.norm(p_k) > tol and it < Nmax:
        p_k /= la.norm(p_k)
        alpha = backtracking_linesearch_augL(f,l_k, mu_k, grad,p_k,x_k)
        l_k = updateL(l_k, x_k, mu_k)
        mu_k = updateMu(mu_k)
        x_k = x_k+alpha*p_k
        p_k = -grad(x_k, l_k, mu_k)
        
        it += 1
        
        conv_p += [x_k]
            
        
            
        if la.norm(x_k - x_k_,2)<tol:
            print('converged')
            return x_k,it,f(x_k, l_k, mu_k), l_k, mu_k, np.array(conv_p)
        x_k_ = x_k
        
        
        
    return x_k,it,f(x_k, l_k, mu_k), l_k, mu_k, np.array(conv_p)

def backtracking_linesearch_augL(f,l, mu, gradf,p,x):
    rho = 0.5
    c = 0.5
    a = 0.5
    Nmax = 1000
    
    f0 = f(x, l, mu)
    phi = f(x+a*p, l, mu)
    dF = np.array(gradf(x, l, mu))
    
    it = 0
    
    while (phi >= (f0 + c*a*dF.dot(p)) and it < Nmax):
        a = rho*a
        phi = f(x+a*p, l, mu)
        it += 1
    return a



def updateMu(mu):
    return mu*100

