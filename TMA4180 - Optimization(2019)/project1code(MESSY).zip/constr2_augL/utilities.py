import numpy as np
from matplotlib import pyplot as plt
import numpy.linalg as la
import datetime
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.cm as cm

def r_i(c, r, z_i):
    return la.norm(z_i-c, 2)**2 -r**2

def R(c, r, z):
    res = np.zeros((len(z),1))
    for i in range(0, len(z)):
        res[i] = r_i(c, r, z[i])
    return res
        
def dRdc(c, r, z):
    res = np.zeros(z.shape)
    for i in range(0, len(z)):
        res[i,:] = -2*(z[i]-c)
    return res

def gen_data(xrange, yrange, c1, c2, r1, r2, N, per):
    points_x = (np.random.rand(N)-0.5)*xrange
    points_y = (np.random.rand(N)-0.5)*yrange
    
    w = np.array([points_x, points_y])
    w = w.T
    z = np.zeros((len(w),1))
    for i in range(0, len(w)):
        if r_i(c1, r1, w[i]) < 0:
            z[i] = -1 # circle 1
        if r_i(c2, r2, w[i]) < 0:
            z[i] = 1# cirlce 2
    
    for point in w:
        perturbation = np.random.randn(2)*per
        point += perturbation
    return w, z

def plot_result(label, xrange, yrange, w, z, c1=None, r1=None, c2=None, r2=None, N=10, color='b', title=''):
    colors = ['g' if i==-1 else 'r' if i==1 else 'b' for i in z]
    delta = 1.0/N
    plt.scatter(w[:,0], w[:,1], color=colors)
    if r1 is not None:
        fplot = lambda z: r_i(c1, r1, z)
        xx = np.arange(-xrange*0.5, xrange*0.5 , delta)
        yy = np.arange(-yrange*0.5, yrange*0.5, delta)
        X, Y = np.meshgrid(xx, yy)
        Z = []
        for y_i in range(0,len(yy)):
            Z += [[]]
            for x_i in range(0,len(xx)):
                Z[y_i]  += [fplot(np.array([xx[x_i],yy[y_i]]))]
        CS = plt.contour(X, Y, Z, [0], linewidths=2, zorder=10, color = color)
        plt.clabel(CS, fmt='{0}1'.format(label), fontsize=10)
    if r2 is not None:
        fplot = lambda z: r_i(c2, r2, z)
        xx = np.arange(-xrange*0.5, xrange*0.5 , delta)
        yy = np.arange(-yrange*0.5, yrange*0.5, delta)
        X, Y = np.meshgrid(xx, yy)
        Z = []
        for y_i in range(0,len(yy)):
            Z += [[]]
            for x_i in range(0,len(xx)):
                Z[y_i]  += [fplot(np.array([xx[x_i],yy[y_i]]))]
        CS = plt.contour(X, Y, Z, [0], linewidths=2, zorder=10, color= color)
        plt.clabel(CS, fmt='{0}2'.format(label), fontsize=10)
    plt.title(title)
    plt.axis('equal')
    #plt.show()
    
def plot_level_curves(
    f, 
    xrange, 
    yrange, 
    mode, 
    title, 
    param, 
    xpoints=None, 
    ypoints=None, 
    delta = 0.5
    ):
    
    #plt.hot()
    x_lower = xrange[0]
    x_upper = xrange[1]
    y_lower = yrange[0]
    y_upper = yrange[1]
    xx = np.arange(x_lower,x_upper,delta)
    yy = np.arange(y_lower,y_upper,delta)
    X, Y = np.meshgrid(xx,yy)
    Z = []
    now = datetime.datetime.now()
    for y_i in range(0, len(yy)):
        Z +=  [[]]
        for x_i in range(0,len(xx)):
            Z[y_i].append(f(xx[x_i], yy[y_i]))
    Z = np.array(Z)
    if mode == 'contour':                                    
        plt.imshow(Z, interpolation='bilinear',
                        origin='lower', cmap=cm.Blues, 
                        extent=(x_lower,x_upper,y_lower,y_upper))
        plt.contour(X,Y,Z, cmap =cm.Blues)
        
    if mode == '3D':
        fig = plt.figure()
        ax = Axes3D(fig)
        ax.plot_surface( X, Y, Z)
    if xpoints!= None:
        plt.plot(xpoints,ypoints,'k-',linewidth=1)
    
    
    #plt.savefig('level_curves/{0}_{1}_{2}{3}{4}_{5}{6}{7}.png'.format(title, param, now.year, now.month, now.day, now.hour, now.minute, now.second))
    plt.title(title)
    
def x2circles(x):
    return np.array(x[0:2]), x[2], np.array(x[3:5]), x[5]

def circles2x(c1, r1, c2, r2):
    x = [0,0,0,0,0,0]
    x[0:2] = c1
    x[2] = r1
    x[3:5] = c2
    x[5] = r2
    return np.array(x)

def f3(x, w, z):
    c1, r1, c2, r2 = x2circles(x)
    label1datx = np.extract(z==-1,w[:,0])
    label1daty = np.extract(z==-1, w[:,1])
    label1dat =np.array([label1datx, label1daty]).T
    
    label2datx = np.extract(z==1,w[:,0])
    label2daty = np.extract(z==1, w[:,1])
    label2dat =np.array([label2datx, label2daty]).T
    
    labeln1datx = np.extract(z!=-1,w[:,0])
    labeln1daty = np.extract(z!=-1, w[:,1])
    labeln1dat =np.array([labeln1datx, labeln1daty]).T
    
    labeln2datx = np.extract(z!=1,w[:,0])
    labeln2daty = np.extract(z!=1, w[:,1])
    labeln2dat =np.array([labeln2datx, labeln2daty]).T
    
    #plt.scatter(labeln1dat[:,0], labeln1dat[:,1], color='orange')
    #plt.scatter(labeln2dat[:,0], labeln2dat[:,1], color='black')
    
    if len(label1datx) != 0:
        p1 = np.sum(np.max(R(c1,r1,label1dat),0)**2)
    else:
        p1 = 0
    p2 = np.sum(np.max(R(c2,r2,label2dat),0)**2)
    p3 = np.sum(np.min(R(c1,r1,labeln1dat),0)**2)
    p4 = np.sum(np.min(R(c2,r2,labeln2dat),0)**2)
        
    return p1+p2+p3+p4

def df3(x, w, z):
    c1, r1, c2, r2 = x2circles(x)
     
    Rc1 = R(c1,r1, w)
    Rc2 = R(c2,r2, w)
    
    label1datx = np.extract(np.logical_and(z==-1,Rc1 >0),w[:,0])
    label1daty = np.extract(np.logical_and(z==-1,Rc1 >0), w[:,1])
    label1dat =np.array([label1datx, label1daty]).T
    
    label2datx = np.extract(np.logical_and(z==1 , Rc2 > 0),w[:,0])
    label2daty = np.extract(np.logical_and(z==1 , Rc2 > 0), w[:,1])
    label2dat =np.array([label2datx, label2daty]).T
    
    labeln1datx = np.extract(np.logical_and(z!=-1 , Rc1<0),w[:,0])
    labeln1daty = np.extract(np.logical_and(z!=-1 , Rc1<0), w[:,1])
    labeln1dat =np.array([labeln1datx, labeln1daty]).T
    
    labeln2datx = np.extract(np.logical_and(z!=1 , Rc2<0),w[:,0])
    labeln2daty = np.extract(np.logical_and(z!=1 , Rc2<0), w[:,1])
    labeln2dat =np.array([labeln2datx, labeln2daty]).T
    
    dp1dc1 = 2*R(c1,r1, label1dat).T.dot(dRdc(c1,r1, label1dat))
    dp1dr1 = np.sum(-4*R(c1,r1, label1dat)*r1)
    
    dp2dc1 = 2*R(c1,r1, labeln1dat).T.dot(dRdc(c1,r1, labeln1dat))
    dp2dr1 = np.sum(-4*R(c1,r1, labeln1dat)*r1)

    #plt.scatter(labeln1datx, labeln1daty, color='orange')
    #plt.scatter(labeln2datx, labeln2daty, color='purple')
    #plt.show()


    dp3dc2 = 2*R(c2,r2, label2dat).T.dot(dRdc(c2,r2, label2dat))
    dp3dr2 = np.sum(-4*R(c2,r2, label2dat)*r2)
    


    dp4dr2 = np.sum(-4*R(c2,r2, labeln2dat)*r2)
    dp4dc2 = 2*R(c2,r2, labeln2dat).T.dot(dRdc(c2,r2, labeln2dat))

    
    dc1 = dp1dc1+dp2dc1
    dc2 = dp3dc2+dp4dc2
    dr1 = dp1dr1 + dp2dr1
    dr2 = dp3dr2 + dp4dr2
    
    
    dx = circles2x(dc1[0], dr1, dc2[0], dr2)
    
    return dx 

def co0(x):
    c1, r1, c2, r2 = x2circles(x)
    if -r1<0:
        return 0.0
    else:
        return -r1
    
def dco0(x):
    c1, r1, c2, r2 = x2circles(x)
    if co0(x)>0:
        return np.array([0,0, -1, 0, 0, 0])
    else: 
        return np.array([0,0,0,0,0,0])

def co1(x):
    c1, r1, c2, r2 = x2circles(x)
    if -r2<0:
        return 0.0
    else:
        return -r2
    
def dco1(x):
    c1, r1, c2, r2 = x2circles(x)
    if co1(x)>0:
        return np.array([0,0,0,0,0,-1])
    else:
        return np.array([0,0,0,0,0,0])
    
def co2(x):
    c1, r1, c2, r2 = x2circles(x)
    res = -la.norm(c1-c2)+abs(r1)+abs(r2)
    if res <0:
        return 0.0
    else:
        return res
    
def dco2(x):
    c1, r1, c2, r2 = x2circles(x)
    if co2(x)>0:
        dc2dr1=r1
        dc2dr2=r2
        dc2dc1 = -0.5/la.norm(c1-c2)*2*(c1-c2)
        dc2dc2 = 0.5/la.norm(c1-c2)*2*(c1-c2)
        return circles2x(dc2dc1, dc2dr1, dc2dc2, dc2dr2)
    else:
        return np.array([0,0,0,0,0,0])
    
def f3augL(x, w, z, l, mu):
    p1 = f3(x, w, z)
    p2 = -l[0]*co0(x)-l[1]*co1(x)-l[2]*co2(x)
    p3 = 0.5*mu**2*(co0(x)**2+co1(x)**2+co2(x)**2)
    return p1+p2+p3

def df3augL(x, w, z, l, mu):
    p1 = df3(x, w, z)
    p2 = -l[0]*dco0(x)-l[1]*dco1(x)-l[2]*dco2(x)
    p3 = mu*(co0(x)*dco0(x)+co1(x)*dco1(x)+co2(x)*dco2(x))
    return p1+p2+p3


def set_funcs_augL(z,w):
    return lambda x, l, mu: f3augL(x, w, z, l, mu), \
           lambda x, l, mu: df3augL(x, w, z, l, mu),\
           lambda l, x, mu: updateL(l, x, mu ), 